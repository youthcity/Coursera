package it.cast.listview;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import it.cast.listview.Activity02.MyBaseAdapter;

public class Activity03 extends Activity {
	private ListView mListView;
	ArrayList<HashMap<String, String>> list = new ArrayList<HashMap<String,String>>();
	HashMap<String, String> map1 =new HashMap<String, String>();
	HashMap<String, String> map2 =new HashMap<String, String>();
	HashMap<String, String> map3 =new HashMap<String, String>();
	HashMap<String, String> map4 =new HashMap<String, String>();
	HashMap<String, String> map5 =new HashMap<String, String>();
	HashMap<String, String> map6 =new HashMap<String, String>();
	HashMap<String, String> map7 =new HashMap<String, String>();
	HashMap<String, String> map8 =new HashMap<String, String>();
	HashMap<String, String> map9 =new HashMap<String, String>();
	HashMap<String, String> map10 =new HashMap<String, String>();
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_view);
		map1.put("name", "�����̳�");
		map2.put("name", "QQ");
		map3.put("name", "QQ������");
		map4.put("name", "����΢��");
		map5.put("name", "��è");
		map6.put("name", "UC�����");
		map7.put("name", "΢��");
		map8.put("name", "֪��");
		map9.put("name", "ʵϰɮ");
		map10.put("name", "ʲôֵ����");
		
		list.add(map1);
		list.add(map2);
		list.add(map3);
		list.add(map4);
		list.add(map5);
		list.add(map6);
		list.add(map7);
		list.add(map8);
		list.add(map9);
		list.add(map10);


		final LayoutInflater inflater = LayoutInflater.from(this);
        View headView = inflater.inflate(R.layout.view_header, null, false);
        //��ʼ��ListView�ؼ�
		mListView = (ListView) findViewById(R.id.lv);
		//����һ��Adapterʵ��
//		MyBaseAdapter mAdapter = new MyBaseAdapter();
		SimpleAdapter mAdapter = new SimpleAdapter(this, list, R.layout.list_item,new String[]{"name"} , new int[] {R.id.tv_list});
		mListView.addHeaderView(headView);
		mListView.setAdapter(mAdapter);
	}

	 

	

}
