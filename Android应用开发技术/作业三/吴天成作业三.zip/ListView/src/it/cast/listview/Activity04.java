package it.cast.listview;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import it.cast.listview.Activity02.MyBaseAdapter;

public class Activity04 extends Activity {
	private ListView mListView;
	private ArrayList<String> list = new ArrayList<String>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_view);
		list.add("�����̳�");
		list.add("QQ");
		list.add("QQ������");
		list.add("��è");
		list.add("UC�����");
		list.add("΢��");
		list.add("֪��");
		list.add("ʵϰɮ");
		list.add("ʲôֵ����");
		
		
		final LayoutInflater inflater = LayoutInflater.from(this);
        View headView = inflater.inflate(R.layout.view_header, null, false);
        //��ʼ��ListView�ؼ�
		mListView = (ListView) findViewById(R.id.lv);
		//����һ��Adapterʵ��
		ArrayAdapter mAdapter = new ArrayAdapter(this, R.layout.list_item,R.id.tv_list,list);
		mListView.addHeaderView(headView);
		mListView.setAdapter(mAdapter);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity04, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
