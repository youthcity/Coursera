package it.cast.listview;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity implements View.OnClickListener {
	private ListView mListView;
	private String[] names = {"�����̳�", "QQ", "QQ������", "����΢��", "��è" , "UC�����" , "΢��", "֪��", "ʵϰɮ", "ʲôֵ����"};
	private Button btnbase;
	private Button btnsim;
	private Button btnarr;
	
 	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		btnbase = (Button) findViewById(R.id.button1);
		btnsim = (Button) findViewById(R.id.button2);
		btnarr = (Button) findViewById(R.id.button3);
		
		btnbase.setOnClickListener(this);
		btnsim.setOnClickListener(this);
		btnarr.setOnClickListener(this);
		
 	}
 	
 
 	

	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.button1:
			Intent intent = new Intent(this,Activity02.class);
			startActivity(intent);

			break;
		case R.id.button2:
			Intent intent2 = new Intent(this,Activity03.class);
			startActivity(intent2);
			
			break;
		case R.id.button3:
			Intent intent3 = new Intent(this,Activity04.class);
			startActivity(intent3);
			
			break;
		default:
			break;
		}
	}


}
